<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title></title>
    <link rel="stylesheet" href="https://cdn.tailwindcss.com/3.4.1" type="text/css" media="all" />
  </head>
  <body>
    <div class="h-8 w-8 bg-red border-2 border-gray-100">
      
    </div>
  </body>
</html>