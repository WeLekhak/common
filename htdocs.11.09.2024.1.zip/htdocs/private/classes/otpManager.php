// File: private/classes/otpManager.php

<?php

class OTPManager {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function storeOTP($email, $otp, $expiry) {
        // Get the user_id from the email
        $stmt = $this->db->prepare(
            "SELECT id FROM lekhak_users WHERE lekhak_email = :email"
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if ($user) {
            $user_id = $user['id'];

            // Insert or update the OTP in the forget_password table
            $stmt = $this->db->prepare(
                "REPLACE INTO forget_password (user_id, otp_sent, sent_time) 
                 VALUES (:user_id, :otp, :expiry)"
            );
            $stmt->execute([
                ':user_id' => $user_id,
                ':otp' => $otp,
                ':expiry' => $expiry
            ]);
        } else {
            throw new Exception("User not found.");
        }
    }
    
    public function verifyOTP($email, $otp) {
        $stmt = $this->db->prepare(
            "SELECT otp_sent, sent_time FROM forget_password 
             WHERE user_id = (SELECT id FROM lekhak_users WHERE lekhak_email = :email)"
        );
        $stmt->execute([':email' => $email]);
        $record = $stmt->fetch();

        if ($record) {
            $currentTime = time();
            if ($record['otp_sent'] === $otp && $currentTime <= $record['sent_time']) {
                return true;
            }
        }
        return false;
    }
}

?>
