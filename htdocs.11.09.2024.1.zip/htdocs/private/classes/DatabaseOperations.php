<?php

class DatabaseOperations {
  private static $pdo;
  private static $result;
  private static $LastUserId;
  private static $nextUserKey;

  public static function initialize($pdo) {
    self::$pdo = $pdo;
  }

  public static function getLastRecord($table, $orderByColumn = 'lekhak_user_id') {
    if (!self::$pdo) {
      throw new Exception("Database connection not initialized.");
    }

    $sql = "SELECT * FROM " . $table . " ORDER BY " . $orderByColumn . " DESC LIMIT 1";

    try {
      $statement = self::$pdo->prepare($sql);
      $statement->execute();
      self::$result = $statement->fetch();
      self::$LastUserId = self::$result['lekhak_user_id'];
      
      
      return self::$LastUserId;

    } catch (PDOException $e) {
      error_log("Query failed: " . $e->getMessage());
      return false;
    }
  }


  public static function getNextUserKey() {
    self::$nextUserKey = self::getLetter(self::getLastRecord('lekhak_users'));
    return '1us' . self::$nextUserKey;
    
  }


  public static function getLetter($number) {
    $result = '';
    
    $number = $number + 1;
    while ($number > 0) {
      $number--; // Adjust for 0-based index
      $result = chr($number % 26 + ord('A')) . $result;
      $number = intdiv($number, 26);
    }
    return strtolower($result);
  }
}

// Usage example:
/*
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'lekhakin_masterdb';
$charset = ''; // Leave empty to use default UTF-8.
$driverOptions = [
    // Add additional driver options here if needed
];

DatabaseConnection::initialize($host, $username, $password, $database, $charset, $driverOptions);

$pdo = DatabaseConnection::getPdo();
DatabaseOperations::initialize($pdo);

// Example usage for retrieving the last record
$lastRecord = DatabaseOperations::getLastRecord('lekhak_users'); // Replace 'users' with your table name

if ($lastRecord !== false) {
    print_r($lastRecord);
} else {
    echo "Error retrieving last record.";
}
*/
?>