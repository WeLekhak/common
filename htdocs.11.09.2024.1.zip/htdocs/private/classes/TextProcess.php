<?php

class TextProcess {

    // Ensure input is always a string and throw an exception if it's not
    private static function validateInput($text) {
        if (!is_string($text)) {
            throw new InvalidArgumentException("Input must be a string.");
        }
    }

    // Method to clean up text by removing extra spaces, HTML tags, etc.
    public static function cleanText($text) {
        self::validateInput($text);
        $cleanedText = trim($text);
        $cleanedText = strip_tags($cleanedText);
        $cleanedText = preg_replace('/\s+/', ' ', $cleanedText);
        return $cleanedText;
    }

    // Method to convert text to uppercase
    public static function toUpperCase($text) {
        self::validateInput($text);
        return strtoupper($text);
    }

    // Method to convert text to lowercase
    public static function toLowerCase($text) {
        self::validateInput($text);
        return strtolower($text);
    }

    // Method to find a specific word or phrase in the text
    public static function findWord($text, $word) {
        self::validateInput($text);
        return strpos($text, $word) !== false;
    }

    // Method to replace a word or phrase in the text
    public static function replaceWord($text, $search, $replace) {
        self::validateInput($text);
        return str_replace($search, $replace, $text);
    }

    // Method to count the number of words in the text
    public static function wordCount($text) {
        self::validateInput($text);
        return str_word_count($text);
    }

    // Method to generate a summary of the text
    public static function generateSummary($text, $length = 50) {
        self::validateInput($text);
        return substr($text, 0, $length) . '...';
    }

    // Method to remove special characters from the text
    public static function removeSpecialCharacters($text) {
        self::validateInput($text);
        return preg_replace('/[^a-zA-Z0-9\s]/', '', $text);
    }

    // Method to remove numbers from the text
    public static function removeNumbers($text) {
        self::validateInput($text);
        return preg_replace('/[0-9]/', '', $text);
    }

    // Method to remove letters from the text
    public static function removeLetters($text) {
        self::validateInput($text);
        return preg_replace('/[a-zA-Z]/', '', $text);
    }

    // Method to remove UTF-8 (non-ASCII) characters from the text
    public static function removeUtf8($text) {
        self::validateInput($text);
        return preg_replace('/[^\x00-\x7F]/', '', $text);
    }

    // Method to remove spaces from the text
    public static function removeSpaces($text) {
        self::validateInput($text);
        return str_replace(' ', '', $text);
    }

    // Method to count occurrences of a specific character or word in the text
    public static function countOccurrences($text, $substring) {
        self::validateInput($text);
        return substr_count($text, $substring);
    }

    // Method to keep only specified characters in the text
    public static function keepOnly($text, $allowedCharacters) {
        self::validateInput($text);
        return preg_replace('/[^' . preg_quote($allowedCharacters, '/') . ']/', '', $text);
    }

    // Method to keep only English letters in the text
    public static function keepOnlyEnglishLetters($text) {
        self::validateInput($text);
        return preg_replace('/[^a-zA-Z]/', '', $text);
    }

    // Method to keep only numbers in the text
    public static function keepOnlyNumbers($text) {
        self::validateInput($text);
        return preg_replace('/[^0-9]/', '', $text);
    }

    // Method to keep only numbers and English letters without spaces
    public static function keepOnlyNumbersAndLettersNoSpace($text) {
        self::validateInput($text);
        return preg_replace('/[^a-zA-Z0-9]/', '', $text);
    }

    // Method to convert text to lowercase
    public static function lowerCase($text) {
        self::validateInput($text);
        return strtolower($text);
    }

    // Method to convert text to uppercase
    public static function upperCase($text) {
        self::validateInput($text);
        return strtoupper($text);
    }
}

/**
 * Example usage:
$text = "Hello, World! 1234 你好 👋";

$cleanedText = TextProcess::cleanText($text);
$noSpecialChars = TextProcess::removeSpecialCharacters($text);
$noNumbers = TextProcess::removeNumbers($text);
$noLetters = TextProcess::removeLetters($text);
$noUtf8 = TextProcess::removeUtf8($text);
$noSpaces = TextProcess::removeSpaces($text);
$occurrences = TextProcess::countOccurrences($text, 'l');
$onlyNumbers = TextProcess::keepOnlyNumbers($text);
$onlyEnglishLetters = TextProcess::keepOnlyEnglishLetters($text);
$onlyAllowed = TextProcess::keepOnly($text, 'HW123');
$onlyNumbersAndLettersNoSpace = TextProcess::keepOnlyNumbersAndLettersNoSpace($text);
$lowerCaseText = TextProcess::lowerCase($text);
$upperCaseText = TextProcess::upperCase($text);

echo "Cleaned Text: $cleanedText\n";
echo "No Special Characters: $noSpecialChars\n";
echo "No Numbers: $noNumbers\n";
echo "No Letters: $noLetters\n";
echo "No UTF-8 Characters: $noUtf8\n";
echo "No Spaces: $noSpaces\n";
echo "Occurrences of 'l': $occurrences\n";
echo "Only Numbers: $onlyNumbers\n";
echo "Only English Letters: $onlyEnglishLetters\n";
echo "Only Allowed Characters (H, W, 1, 2, 3): $onlyAllowed\n";
echo "Only Numbers and Letters (No Spaces): $onlyNumbersAndLettersNoSpace\n";
echo "Lowercase Text: $lowerCaseText\n";
echo "Uppercase Text: $upperCaseText\n";
*/
?>
