<?php

class ImageValidator {

    // Method to verify an image file
    public static function validateImageFile(string $filePath): bool {
        return exif_imagetype($filePath) !== false;
    }

    // Method to verify a Base64 encoded image string
    public static function validateBase64Image(string $base64String): bool {
        // Check if the string starts with a valid Base64 image prefix
        if (preg_match('/^data:image\/(\w+);base64,/', $base64String, $type)) {
            $data = substr($base64String, strpos($base64String, ',') + 1);
            $data = base64_decode($data);

            if ($data === false) {
                return false;
            }

            // Try creating an image from the decoded data
            return @imagecreatefromstring($data) !== false;
        }

        return false;
    }

    // Method to verify binary image data
    public static function validateBinaryData(string $binaryData): bool {
        // Try creating an image from the binary data
        return @imagecreatefromstring($binaryData) !== false;
    }
}

/* Example usage:

// 1. Validate an image file
$imageFilePath = 'path/to/your/image.jpg';
if (ImageValidator::validateImageFile($imageFilePath)) {
    echo "Valid image file.";
} else {
    echo "Invalid image file.";
}

// 2. Validate a Base64 encoded image string
$base64Image = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUA...";
if (ImageValidator::validateBase64Image($base64Image)) {
    echo "Valid Base64 image data.";
} else {
    echo "Invalid Base64 image data.";
}

// 3. Validate binary image data
$binaryData = file_get_contents('path/to/your/image.jpg');
if (ImageValidator::validateBinaryData($binaryData)) {
    echo "Valid binary image data.";
} else {
    echo "Invalid binary image data.";
}
*/
?>
