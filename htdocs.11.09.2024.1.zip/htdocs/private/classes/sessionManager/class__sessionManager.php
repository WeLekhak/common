<?php

class SessionManager {
  
  // Start a new session or resume an existing one
  public static function startSession() {
    if (session_status() == PHP_SESSION_NONE) {
      session_start();
    }
  }

  // Log in a user by setting session variables
  public static function loginUser($userData) {
    self::startSession();
    $_SESSION['user'] = $userData;  // Storing user data (e.g., user ID, username, email, etc.)
  }

  // Check if a user is logged in
  public static function isLoggedIn() {
    self::startSession();
    return isset($_SESSION['user']);
  }

  // Get the logged-in user's data
  public static function getUserData() {
    self::startSession();
    return $_SESSION['user'] ?? null;
  }

  // Log out the user by destroying the session
  public static function logoutUser() {
    self::startSession();
    session_unset();  // Remove all session variables
    session_destroy();  // Destroy the session
  }

  // Redirect to a given URL
  public static function redirect($url) {
    header("Location: $url");
    exit();
  }

  // Redirect to the login page if not logged in
  public static function requireLogin($loginPage = '/login/') {
    if (!self::isLoggedIn()) {
      self::redirect($loginPage);
    }
  }
}

?>
