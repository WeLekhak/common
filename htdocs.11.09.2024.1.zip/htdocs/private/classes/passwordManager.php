<?php
class PasswordManager {
    public function updatePassword($email, $hashedPassword) {
        $db = DatabaseConnection::getConnection();
        $stmt = $db->prepare("UPDATE lekhak_users SET lekhak_password = ? WHERE lekhak_email = ?");
        $stmt->execute([$hashedPassword, $email]);
    }
}
?>
