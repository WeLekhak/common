<?php
function removeBrTags($html) {
  // Remove <br> tags at the start of the string
  $html = preg_replace('/^(\s*<br\s*\/?>\s*)+/i', '', $html);

  // Remove consecutive <br> tags and keep only one <br>
  $html = preg_replace('/(<br\s*\/?>\s*){2,}/i', '<br>', $html);

  return $html;
}
?>