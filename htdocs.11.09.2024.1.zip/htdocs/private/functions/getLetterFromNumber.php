<?php

function getLetterFromNumber($number) {
    $result = '';

    while ($number > 0) {
        $number--; // Adjust for 0-based index
        $result = chr($number % 26 + ord('A')) . $result;
        $number = intdiv($number, 26);
    }

    return $result;
}

// Example usage
// echo getLetter(2555); // Output: 'ALE'

?>
