<?php
function generateRandomString($length = 10) {
  // Ensure the length is valid
  $length = max(1, $length);

  // Get the current time in microseconds and convert to hexadecimal
  $time = microtime(true);
  $randomString = dechex($time * 1000000);

  // Truncate or pad the string to the desired length
  return substr(str_pad($randomString, $length, '0', STR_PAD_RIGHT), 0, $length);
}

// Example usage:
// echo generateRandomString(12); // Outputs a random string of 12 characters

?>