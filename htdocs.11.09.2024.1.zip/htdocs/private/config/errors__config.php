<?php



if (!isset($__showerrors)) {
  $__showerrors = 0;
}


if ($__showerrors == 0) {
  error_reporting(0);
  ini_set('display_errors', 0);
} elseif ($__showerrors == 1) {
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
}

?>