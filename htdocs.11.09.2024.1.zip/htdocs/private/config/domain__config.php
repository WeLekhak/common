<?php
$__domain = "lekhak";
$__extension = ".in";
$domain_name = $__domain.$__extension;
$domain_name = "localhost:8080";
?>