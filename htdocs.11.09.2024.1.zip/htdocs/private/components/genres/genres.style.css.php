<style type="text/css" media="all">
  .yatra-one-regular {
    font-family: "Yatra One", system-ui;
    font-weight: 600;
    font-style: normal;
  }
  .crimson-text-regular {
    font-family: "Crimson Text", serif;
    font-weight: 400;
    font-style: normal;
  }
  .hammersmith-one-regular {
    font-family: "Hammersmith One", sans-serif;
    font-weight: 400;
    font-style: normal;
  }
  .bona-nova-sc-regular {
    font-family: "Bona Nova SC", serif;
    font-weight: 400;
    font-style: normal;
  }

  .bona-nova-sc-bold {
    font-family: "Bona Nova SC", serif;
    font-weight: 700;
    font-style: normal;
  }

  .bona-nova-sc-regular-italic {
    font-family: "Bona Nova SC", serif;
    font-weight: 400;
    font-style: italic;
  }

  .ribbon {
    font-size: 12px;
    font-weight: bold;
    color: #fff;

    width: auto;
    min-width: 0;
  }
  .ribbon {

    --f: .5em;
    /* control the folded part*/
    --r: .8em;
    /* control the ribbon shape */

    position: relative;
    top: 0px;
    left: calc(-2.8*var(--f));
    padding-inline: .25em;
    line-height: 1.8;
    background: #b91c1c;
    border-bottom: var(--f)solid #0005;
    border-right: var(--r)solid #0000;
    clip-path:
    polygon(0 0,0 calc(100% - var(--f)),var(--f) 100%,
    var(--f) calc(100% - var(--f)),100% calc(100% - var(--f)),
    calc(100% - var(--r)) calc(50% - var(--f)/2),100% 0);
  }
  #ribbon2 {
    background: #ccc !important;

  }

  .hide-scrollbar {
    overflow-x: auto;
    scrollbar-width: none;
    /* For Firefox */
    -ms-overflow-style: none;
    /* For Internet Explorer and Edge */
  }

  .hide-scrollbar::-webkit-scrollbar {
    display: none;
    /* For Chrome, Safari, and Opera */
  }
  .category_title {
    position: absolute;
    bottom: 0px;
    right: 10px;
    font-weight: bold;
    font-size: 1.3em;
    z-index: 2;
  }
  .category_card {

    background-repeat: no-repeat;
    background-size: 100%;
  }
  .category_card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to
    top left, black, transparent);
    z-index: 1;
  }
</style>