<?php

?>

<style type="text/css" media="all">
    .category_card {
        background-image: url('../assets/images/imageCT.jpeg');
    }
</style>
<div class="categories_title px-6 text-xl mt-4">
    <h3 class="crimson-text-regular">शैली नुसार वाचा.</h3>
</div>
<div class="hide-scrollbar categories overflow-scroll py-2 px-6 grid grid-cols-2 gap-4">
    <?php
    $PDO3 = DatabaseConnection::getPdo(); // Assuming this returns a PDO object

    $SQL3 = "
  SELECT
    g.genreid,
    g.genrename,
    COUNT(p.id) AS post_count
FROM
    genres AS g
INNER JOIN
    postgenres AS pg ON g.genreid = pg.genreid
INNER JOIN
    posts AS p ON pg.postid = p.id
WHERE
      p.timecreated >= (
        SELECT MIN(sub.timecreated)
        FROM (
            SELECT DISTINCT DATE(timecreated) AS timecreated
            FROM posts
            WHERE category = 'poetry'
            ORDER BY timecreated DESC
            LIMIT 100
        ) AS sub
    )
GROUP BY
    g.genreid, g.genrename
ORDER BY
    post_count DESC
LIMIT 100;
  ";


    $stmt3 = $PDO3->prepare($SQL3); // Prepare the SQL statement
    $stmt3->execute(); // Execute the prepared statement

    $results3 = $stmt3->fetchAll(PDO::FETCH_ASSOC); // Fetch all results as an associative array
    foreach ($results3 as $row3) {
        $genrename = $row3["genrename"];
        ?>

        <a href="/genres/index.php?genre=<?php echo $genrename ?>" class="text-white bg-gradient-to-tl from-slate-900 via-transparent via-50% to-transparent category_card overflow-hidden relative min-w-36 h-24 border mr-3 rounded-md">
            <div class="category_title">
                <span class="crimson-text-regular font-bold">
                    <?php echo $genrename ?>
                </span>
            </div>
        </a>

        <?php
    }
    ?>
</div>

