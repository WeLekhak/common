<div class="content">
    <?php
    $PDO = DatabaseConnection::getPdo(); // Assuming this returns a PDO object
    $SQL = "
SELECT
    p.*,
    u.lekhak_firstname,
    u.lekhak_lastname,
    COALESCE(pr.read_count, 0) AS total_reads,
    COALESCE(pl.like_count, 0) AS total_likes,
    GROUP_CONCAT(DISTINCT t.tagname SEPARATOR ', ') AS tags,
    GROUP_CONCAT(DISTINCT g.genrename SEPARATOR ', ') AS genres
FROM
    posts AS p
LEFT JOIN
    lekhak_users AS u ON p.author = u.lekhak_user_id
LEFT JOIN
    (SELECT postread_postid, COUNT(*) AS read_count
     FROM postreads
     GROUP BY postread_postid) AS pr ON p.id = pr.postread_postid
LEFT JOIN
    (SELECT postid, COUNT(*) AS like_count
     FROM post_likes
     GROUP BY postid) AS pl ON p.id = pl.postid
LEFT JOIN
    posttags AS pt ON p.id = pt.posttags_postid
LEFT JOIN
    tags AS t ON pt.posttags_tagid = t.tagid
LEFT JOIN
    postgenres AS pg ON p.id = pg.postid
LEFT JOIN
    genres AS g ON pg.genreid = g.genreid
WHERE
    g.genrename IN (:genre)  -- Replace with your specific genres
GROUP BY
    p.id
ORDER BY
    p.id DESC
LIMIT 10;
      ";

    $stmt = $PDO->prepare($SQL); // Prepare the SQL statement
    $stmt->execute(["genre" => $_genre]); // Execute the prepared statement
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all results as an associative array
    echo("<pre>");
    //print_r($results); // Print the results
    echo("</pre>");

    foreach ($results as $row) {
        $language = 'mr';
        $category = 'categories';
        $selectedText = $row["category"];
        $displayText = LanguageHandler::getTranslation($language, $category, $selectedText);

        ?>

        <div id="card" class="px-6 mb-4 w-full h-full ">
            <div class="bg-white flex flex-col border-2 rounded-md overflow-hidden py-1 pb-2">

                <div id="card_head" class="flex-col py-1 px-2 flex justify-center">
                    <!--<div class="ribbon uppercase hammersmith-one-regular pl-3 min-w-0 w-auto">-->
                    <!--  #7 Festivel Awards - week 52-->
                    <!--</div>-->
                    <a class="text-lg text-gray-700 yatra-one-regular" href="../posts/index.php?post=<?php echo($row["lekh_key"]); ?>" class="px-2 min-h-0 h-auto overflow-y-auto">
                        <?php echo($row["title"]); ?>
                    </a>
                    <span class="crimson-text-regular text-sm text-gray-600">
                        <?php echo($displayText); ?>
                    </span>
                </div>

                <div class="h-full flex card_main ">
                    <div class=" rounded-md overflow-hidden flex-shrink-0 px-2 cover_image h-52 w-40 overflow-hidden">
                        <img class="rounded-md overflow-hidden h-full" src="../assets/images/BookCover.jpg" />
                    </div>
                    <div id="card_head" class="flex-grow flex flex-col yatra-one-regular border-red-700">
                        <div class=" flex items-center ">
                            <!--
                                                                                                                                                                                                                                                                                                            <div class="flex-shrink rounded-full">
                                                                                                                                                                                                                                                                                                              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" style="fill: #6b7280;transform: ;msFilter:;"><path d="M12 2A10.13 10.13 0 0 0 2 12a10 10 0 0 0 4 7.92V20h.1a9.7 9.7 0 0 0 11.8 0h.1v-.08A10 10 0 0 0 22 12 10.13 10.13 0 0 0 12 2zM8.07 18.93A3 3 0 0 1 11 16.57h2a3 3 0 0 1 2.93 2.36 7.75 7.75 0 0 1-7.86 0zm9.54-1.29A5 5 0 0 0 13 14.57h-2a5 5 0 0 0-4.61 3.07A8 8 0 0 1 4 12a8.1 8.1 0 0 1 8-8 8.1 8.1 0 0 1 8 8 8 8 0 0 1-2.39 5.64z"></path><path d="M12 6a3.91 3.91 0 0 0-4 4 3.91 3.91 0 0 0 4 4 3.91 3.91 0 0 0 4-4 3.91 3.91 0 0 0-4-4zm0 6a1.91 1.91 0 0 1-2-2 1.91 1.91 0 0 1 2-2 1.91 1.91 0 0 1 2 2 1.91 1.91 0 0 1-2 2z"></path></svg>
                                                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                                                            -->
                            <h2 class="text-gray-600 flex items-center crimson-text-regular font-bold">
                                <span>
                                    <?php echo($row["lekhak_firstname"]." ".$row["lekhak_lastname"]); ?>
                                </span>
                            </h2>
                        </div>
                        <div class="tagdetails uppercase hammersmith-one-regular">

                            <div class="">
                                <span class="text-white px-2 text-xs bg-red-700 ">
                                    #<?php echo($row["genres"]); ?>
                                </span>
                            </div>
                            <div class="">
                                <?php
                                $tagsstr = $row["tags"];

                                // Check if $tagsstr is not null or empty
                                if (!empty($tagsstr)) {
                                    $tagsarr = explode(",", $tagsstr);
                                    foreach ($tagsarr as $tag) {
                                        ?>
                                        <span class="mr-1 px-2 text-gray-600 text-xs bg-gray-200">
                                            <?php echo htmlspecialchars(trim($tag)); // Trim whitespace and escape HTML ?>
                                        </span>
                                        <?php
                                    }
                                } else {
                                    // Optionally, handle the case where there are no tags
                                    echo '<span class="text-gray-400 text-xs">No tags available</span>';
                                }
                                ?>
                            </div>


                        </div>
                        <div class="ratings  mt-2">
                            <div class="flex h-8 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 48 48" style="fill: #059669;transform: ;msFilter:;"><path d="M24 34.54 36.36 42l-3.27-14.06L44 18.49l-14.38-1.24L24 4l-5.62 13.25L4 18.49l10.91 9.45L11.64 42z" /><path fill="none" /></svg>
                                <span class="crimson-text-regular text-lg ">
                                    4.7 Rated
                                </span>

                            </div>
                            <span class="text-gray-600 crimson-text-regular">
                                1207 Reviews
                            </span>

                        </div>


                    </div>
                </div>

            </div>
        </div>
        <?php
    }
    ?>

</div>