
<?php  ?>
<style>
  .bg-dark-gray {
    background-color: #1d1f20;
  }
  #shortmenu {
    z-index: 999;
  }
  #mobile-menu {
    transition: height 0.3s ease-out;
  }
  * {
    -webkit-tap-highlight-color: transparent;
  }
</style>
<nav class="border-b bg-white z-20 ">
  <div class="overflow-hidden max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">

  </div>
  <!-- Mobile menu, show/hide based on menu state. -->




  <!--<div class="font-fam-yatra pt-4 text-gray-700">-->
  <!--  <h1 class="w-full text-2xl font-fam-yatra text-center">WeLekhak</h1>-->
  <!--  <p class="w-full font-fam-yatra text-xl text-red-500 text-center">-->
  <!--    लेखकांचेे हक्काचे व्यासपीठ !!!-->
  <!--  </p>-->
  <!--</div>-->

  <div class="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
    <div class="relative flex items-center justify-between h-14">
      <div class="absolute inset-y-0 left-0 flex items-center sm:hidden">
        <!-- Mobile menu button-->
        <button id="toggle-button" onclick="openMenu()" type="button" class="inline-flex text-stroke items-center justify-center p-2 rounded-md text-gray-600 hover:text-gray-500 focus:outline-none focus:border-2 focus:ring-inset focus:border-gray-200" aria-controls="mobile-menu" aria-expanded="false">
          <span class="sr-only">Open main menu</span>

          <!--Icon when menu is closed.-->
          <!--Heroicon name: outline/menu-->
          <!--Menu open: "hidden", Menu closed: "block"-->

          <svg id="iconmenu" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd" />
          </svg>

          <!--Icon when menu is open.-->
          <!--Heroicon name: outline/x-->
          <!--Menu open: "block", Menu closed: "hidden"-->

          <svg id="iconx" class="hidden h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />


          </svg>
        </button>

        <!--Notification Icon-->
        <!--<button type="button" class="inline-flex text-stroke items-center justify-center p-2 rounded-md text-gray-600 hover:text-gray-500 focus:outline-none focus:border-2 focus:ring-inset focus:border-gray-200" aria-controls="mobile-menu" aria-expanded="false">-->
        <!--  <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">-->
        <!--    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />-->
        <!--    <span class="absolute top-2 -right-2 p-1 text-xs font-bold leading-none text-red-700 transform bg-red-50 rounded-full">-->
        <!--      3+-->
        <!--    </span>-->
        <!--  </svg>-->
        <!--</button>-->

      </div>
      <div class="flex-1 flex items-center justify-center sm:items-stretch sm:justify-start">
        <div class="flex-shrink-0 text-red-500 flex items-center">
          <a style="font-size: 2.25rem;" class="text-xl" href="http://<?php echo $domain_name ?>">
            <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="feather-alt" class="svg-inline--fa block lg:hidden h-8 w-auto fa-feather-alt fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M512 0C460.22 3.56 96.44 38.2 71.01 287.61c-3.09 26.66-4.84 53.44-5.99 80.24l178.87-178.69c6.25-6.25 16.4-6.25 22.65 0s6.25 16.38 0 22.63L7.04 471.03c-9.38 9.37-9.38 24.57 0 33.94 9.38 9.37 24.59 9.37 33.98 0l57.13-57.07c42.09-.14 84.15-2.53 125.96-7.36 53.48-5.44 97.02-26.47 132.58-56.54H255.74l146.79-48.88c11.25-14.89 21.37-30.71 30.45-47.12h-81.14l106.54-53.21C500.29 132.86 510.19 26.26 512 0z"></path></svg>
          </a>
        </div>
        <div class="hidden sm:block sm:ml-6">
          <div class="flex space-x-4">
            <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
            <a href="#" class="bg-gray-900 text-white px-3 py-2 rounded-md text-sm font-medium" aria-current="page">Dashboard</a>

            <a href="#" class="text-gray-300 hover:bg-gray-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Team</a>

            <a href="#" class="text-gray-300 hover:bg-gray-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Projects</a>

            <a href="#" class="text-gray-300 hover:bg-gray-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium">Calendar</a>
          </div>
        </div>
      </div>
      <div class="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">
        <a href="/write/" class=" p-1 rounded-full text-gray-600 hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white">
          <span class="sr-only">View notifications</span>
          <!-- Heroicon name: outline/bell -->
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
            <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
          </svg>
        </a>

        <!-- Profile dropdown -->
        <div class="ml-3 relative">
          <div>
            <button onclick="openShortMenu()" type="button" class=" flex text-sm rounded-full focus:outline-none  focus:ring-offset-2 focus:ring-offset-gray-800 " id="user-menu" aria-expanded="false" aria-haspopup="true">
              <span class="sr-only">Open user menu</span>
              <img class="h-8 w-8 bg-gray-100 rounded-full overflow-hidden" src="0" alt="">
            </button>
          </div>


          <div id="shortmenu" class="hidden origin-top-right absolute z-100 right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none" role="menu" aria-orientation="vertical" aria-labelledby="user-menu">
            <a href="/profile/" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Your Profile</a>
            <a href="/setting/" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Settings</a>
            <a href="http://lekhak.in/logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Sign out</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="sm:hidden transition overflow-hidden" id="mobile-menu">

    <div class="px-2 pt-2 transition-hei space-y-1">
      <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
      <a href="http://lekhak.in" class="bg-gray-900 text-white block px-3 py-2 rounded-md text-base font-medium" aria-current="page">HomePage</a>

      <a href="http://lekhak.in/library/" class="text-gray-500 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">Library</a>

      <a href="http://lekhak.in/write/" class="text-gray-500 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium">लिहा</a>
    </div>
  </div>
</nav>

<!-- This example requires Tailwind CSS v2.0+ -->
<script type="text/javascript" charset="utf-8">
  var shortmenu = document.getElementById("shortmenu");
  var section = document.getElementById("mobile-menu");
  var iconx = document.getElementById('iconx');
  var iconmenu = document.getElementById('iconmenu');
  // var section = document.querySelector('#mobile-menu');


  function openShortMenu() {
    shortmenu.classList.toggle("hidden");
  }

  function openMenu() {
    //largemenu.classList.remove("hidden");
    iconx.classList.toggle("hidden");
    iconmenu.classList.toggle("hidden");
  }





  function collapseSection(element) {
    // get the height of the element's inner content, regardless of its actual size
    var sectionHeight = element.scrollHeight;

    // temporarily disable all css transitions
    var elementTransition = element.style.transition;
    element.style.transition = '';

    // on the next frame (as soon as the previous style change has taken effect),
    // explicitly set the element's height to its current pixel height, so we
    // aren't transitioning out of 'auto'
    requestAnimationFrame(function() {
      element.style.height = sectionHeight + 'px';
      element.style.transition = elementTransition;

      // on the next frame (as soon as the previous style change has taken effect),
      // have the element transition to height: 0
      requestAnimationFrame(function() {
        element.style.height = 0 + 'px';
      });
    });

    // mark the section as "currently collapsed"
    element.setAttribute('data-collapsed', 'true');
  }

  function expandSection(element) {
    // get the height of the element's inner content, regardless of its actual size
    var sectionHeight = element.scrollHeight;

    // have the element transition to the height of its inner content
    element.style.height = sectionHeight + 'px';

    // when the next css transition finishes (which should be the one we just triggered)
    element.addEventListener('transitionend', function(e) {
      // remove this event listener so it only gets triggered once
      element.removeEventListener('transitionend', arguments.callee);

      // remove "height" from the element's inline styles, so it can return to its initial value
      element.style.height = null;
    });

    // mark the section as "currently not collapsed"
    element.setAttribute('data-collapsed', 'false');
  }

  document.querySelector('#toggle-button').addEventListener('click', function(e) {

    var isCollapsed = section.getAttribute('data-collapsed') === 'true';

    if (isCollapsed) {
      expandSection(section)
      section.setAttribute('data-collapsed', 'false')
    } else {
      collapseSection(section)
    }
  });
  window.onload = function() {}
  collapseSection(section)
</script>

<!---->
<!--<div class="bg-gradient-to-b px-4 from-green-200 border-box via-green-100 to-green-200 w-full flex items-center justify-center">-->
<!--  <a class="text-white text-center text-md font-bold text-green-600" href="https://chat.whatsapp.com/D1lyQuUlpdT48v5zLzifns" target="_blank">-->
<!--    <span class="font-bold">येथे क्लिक</span> करुन आमच्या WhatsApp ग्रुप ला जॉईन व्हा.-->
<!--  </a>-->
<!--</div>-->