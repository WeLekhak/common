<script type="text/javascript" charset="utf-8">
    // script.js

    // Get the modal, open button, and close button elements
    const modal = document.getElementById("myModal");
    const openModalBtn = document.getElementById("openModalBtn");
    const closeModalBtn = document.getElementById("closeModalBtn");

    // When the user clicks on the button, open the modal
    openModalBtn.addEventListener("click", () => {
        modal.classList.remove("modal-hide");
        modal.classList.add("modal-show");
    });

    // When the user clicks on the close button, close the modal
    closeModalBtn.addEventListener("click", () => {
        modal.classList.remove("modal-show");
        modal.classList.add("modal-hide");
    });

    // Optional: Close the modal when clicking outside of the modal content
    window.addEventListener("click", (event) => {
        if (event.target === modal) {
            modal.classList.remove("modal-show");
            modal.classList.add("modal-hide");
        }
    });

</script>
