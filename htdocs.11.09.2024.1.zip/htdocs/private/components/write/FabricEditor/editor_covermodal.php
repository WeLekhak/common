<!-- The Modal -->
<div id="myModal" class="h-full p-4 modal-hide modal-transition absolute w-full inset-0 flex items-center justify-center bg-black bg-opacity-50 overflow-scroll">
  <div class="h-full bg-white border-2 shadow-lg w-full overflow-scroll">
    <div class="bg-white p-4 border-4 shadow-md overflow-scroll">
      <input type="file" id="imageUpload" accept="image/*" class="mb-4">
      <canvas class="border" id="myCanvas" width="300" height="400"></canvas>
      <div class="mt-4 flex flex-col space-y-2">
        <input type="text" id="customText" placeholder="Enter custom text" class="border rounded p-2 mb-2">
        <button id="addText" class="bg-blue-500 text-white px-4 py-2 rounded mb-4">Add Text</button>

        <div class="w-full bg-gray-100 p-1">
          <nav class="flex pl-2 overflow-scroll items-center  transition-all duration-500">
            <div class="custom-color-input border p-2 rounded mr-2">
              <label for="textColor" class="text-gray-700">Text Color:</label>
              <input type="color" id="textColor" value="#000000" class="border rounded">
              <input type="range" id="textColorAlpha" min="0" max="1" step="0.01" value="1">
            </div>

            <div class="flex items-center space-x-2  border p-2 rounded mr-2">
              <label for="textFont" class="text-gray-700">Font Family:</label>
              <select id="textFont" class="border rounded">
                <option value="Anek Devanagari">Anek Devanagari</option>
                <option value="Noto Sans">Noto Sans</option>
                <option value="Mukta">Mukta</option>
                <option value="Khand">Khand</option>
                <option value="Teko">Teko</option>
                <option value="Hind">Hind</option>
                <option value="Rajdhani">Rajdhani</option>
                <option value="Kalam">Kalam</option>
                <option value="Martel">Martel</option>
                <option value="Yatra One">Yatra One</option>
                <option value="Rozha One">Rozha One</option>
                <option value="Gotu">Gotu</option>
              </select>
            </div>

            <div class="flex items-center space-x-2  border p-2 rounded mr-2">
              <label for="fontStyle" class="text-gray-700">Font Style:</label>
              <select id="fontStyle" class="border rounded">
                <option value="normal">Normal</option>
                <option value="italic">Italic</option>
              </select>
            </div>

            <div class="flex items-center space-x-2  border p-2 rounded mr-2">
              <label for="fontWeight" class="text-gray-700">Font Weight:</label>
              <select id="fontWeight" class="border rounded">
                <option value="normal">Normal</option>
                <option value="bold">Bold</option>
              </select>
            </div>

            <div class="flex items-center space-x-2  border p-2 rounded mr-2">
              <label for="underline" class="text-gray-700">Underline:</label>
              <input type="checkbox" id="underline" class="border rounded">
            </div>

            <div class="custom-color-input  border p-2 rounded mr-2">
              <label for="textBgColor" class="text-gray-700">Text Background:</label>
              <input type="color" id="textBgColor" value="#ffffff" class="border rounded">
              <input type="range" id="textBgColorAlpha" min="0" max="1" step="0.01" value="1">
            </div>

            <div class="custom-color-input  border p-2 rounded mr-2">
              <label for="outlineColor" class="text-gray-700">Outline Color:</label>
              <input type="color" id="outlineColor" value="#000000" class="border rounded">
              <input type="range" id="outlineColorAlpha" min="0" max="1" step="0.01" value="1">
              <input type="checkbox" id="enableOutline" class="ml-2"> <!-- Checkbox for enabling/disabling outline -->
            </div>
          </nav>
        </div>


        <div class="flex space-x-2 mt-4">
          <button id="updateText" class="bg-yellow-500 text-white px-4 py-2 rounded">Update Text</button>
          <button id="deleteText" class="bg-red-500 text-white px-4 py-2 rounded">Delete Text</button>
          <button id="saveImage" class="bg-green-500 text-white px-4 py-2 rounded">Save Image</button>
        </div>
      </div>


    </div>

  </div>
</div>