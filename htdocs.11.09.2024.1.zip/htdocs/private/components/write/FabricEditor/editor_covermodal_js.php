<script>
  const canvas = new fabric.Canvas('myCanvas');
  let imageObject = null;

  function loadImage(url) {
    fabric.Image.fromURL(url, function(img) {
      img.scaleToWidth(200);
      img.scaleToHeight(300);
      if (imageObject) {
        canvas.remove(imageObject);
      }
      imageObject = img;
      canvas.add(img);
      canvas.sendToBack(img); // Ensure image stays behind text
      canvas.renderAll();
    });
  }

  document.getElementById('imageUpload').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
        loadImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  });

  document.getElementById('addText').addEventListener('click', () => {
    const customText = document.getElementById('customText').value || 'Hello World';
    const textColor = document.getElementById('textColor').value;
    const textColorAlpha = document.getElementById('textColorAlpha').value;
    const textFont = document.getElementById('textFont').value;
    const fontStyle = document.getElementById('fontStyle').value;
    const fontWeight = document.getElementById('fontWeight').value;
    const underline = document.getElementById('underline').checked;
    const textBgColor = document.getElementById('textBgColor').value;
    const textBgColorAlpha = document.getElementById('textBgColorAlpha').value;
    const outlineColor = document.getElementById('outlineColor').value;
    const outlineColorAlpha = document.getElementById('outlineColorAlpha').value;
    const enableOutline = document.getElementById('enableOutline').checked;

    const rgbaTextColor = hexToRgba(textColor, textColorAlpha);
    const rgbaTextBgColor = hexToRgba(textBgColor, textBgColorAlpha);
    const rgbaOutlineColor = hexToRgba(outlineColor, outlineColorAlpha);

    const textOptions = {
      left: 100,
      top: 100,
      fill: rgbaTextColor,
      fontSize: 20,
      fontFamily: textFont,
      fontStyle: fontStyle,
      fontWeight: fontWeight,
      underline: underline,
      textBackgroundColor: rgbaTextBgColor,
    };

    if (enableOutline) {
      textOptions.stroke = rgbaOutlineColor;
      textOptions.strokeWidth = 1;
    }

    const text = new fabric.Text(customText, textOptions);
    canvas.add(text);
  });

  document.getElementById('updateText').addEventListener('click', () => {
    const activeObject = canvas.getActiveObject();
    if (activeObject && activeObject.type === 'text') {
      const customText = document.getElementById('customText').value;
      const textColor = document.getElementById('textColor').value;
      const textColorAlpha = document.getElementById('textColorAlpha').value;
      const textFont = document.getElementById('textFont').value;
      const fontStyle = document.getElementById('fontStyle').value;
      const fontWeight = document.getElementById('fontWeight').value;
      const underline = document.getElementById('underline').checked;
      const textBgColor = document.getElementById('textBgColor').value;
      const textBgColorAlpha = document.getElementById('textBgColorAlpha').value;
      const outlineColor = document.getElementById('outlineColor').value;
      const outlineColorAlpha = document.getElementById('outlineColorAlpha').value;
      const enableOutline = document.getElementById('enableOutline').checked;

      const rgbaTextColor = hexToRgba(textColor, textColorAlpha);
      const rgbaTextBgColor = hexToRgba(textBgColor, textBgColorAlpha);
      const rgbaOutlineColor = hexToRgba(outlineColor, outlineColorAlpha);

      activeObject.set({
        text: customText,
        fill: rgbaTextColor,
        fontFamily: textFont,
        fontStyle: fontStyle,
        fontWeight: fontWeight,
        underline: underline,
        textBackgroundColor: rgbaTextBgColor,
      });

      if (enableOutline) {
        activeObject.set({
          stroke: rgbaOutlineColor,
          strokeWidth: 1,
        });
      } else {
        activeObject.set({
          stroke: '',
          strokeWidth: 0,
        });
      }

      canvas.renderAll();
    }
  });

  document.getElementById('deleteText').addEventListener('click', () => {
    const activeObject = canvas.getActiveObject();
    if (activeObject && activeObject.type === 'text') {
      canvas.remove(activeObject);
    }
  });

  document.getElementById('saveImage').addEventListener('click', () => {
    const originalWidth = canvas.getWidth();
    const originalHeight = canvas.getHeight();

    // Scale canvas to desired resolution
    const highResMultiplier = 6; // Multiplier for higher resolution
    canvas.setWidth(originalWidth * highResMultiplier);
    canvas.setHeight(originalHeight * highResMultiplier);
    canvas.setZoom(highResMultiplier);

    const dataURL = canvas.toDataURL('image/png');

    // Reset canvas to original size
    canvas.setWidth(originalWidth);
    canvas.setHeight(originalHeight);
    canvas.setZoom(1);
    canvas.renderAll();

    // Save image data to the hidden input
    document.getElementById('savedImage').value = dataURL;

    // Show preview of the saved image
    document.getElementById('imagePreview').src = dataURL;
    modal.classList.remove("modal-show");
    modal.classList.add("modal-hide");
  });

  function hexToRgba(hex, alpha) {
    let r = 0, g = 0, b = 0;
    if (hex.length === 4) {
      r = parseInt(hex[1] + hex[1], 16);
      g = parseInt(hex[2] + hex[2], 16);
      b = parseInt(hex[3] + hex[3], 16);
    } else if (hex.length === 7) {
      r = parseInt(hex[1] + hex[2], 16);
      g = parseInt(hex[3] + hex[4], 16);
      b = parseInt(hex[5] + hex[6], 16);
    }
    return `rgba(${r},${g},${b},${alpha})`;
  }
</script>