<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

<!-- Common Css File -->
<?php require_once("files/editor.style.css.php"); ?>


<div class="px-6 pt-28 mb-32">
    <form class="" method="post" action="#" enctype="multipart/form-data">
        <div class=" overflow-hidden">
            <div id="formContainer" class="form-container ">
                <!-- Form 1: Title and Quill Editor -->
                <div id="form1" class=" form1 w-full h-full">
                    <div class="categories_title text-xl mt-4">
                        <h3 class="crimson-text-regular text-gray-700">
                            शिर्षक
                        </h3>
                    </div>
                    <input required name="title" placeholder="Title" class="mb-4 border-gray-400 outline-none border py-2 px-4 w-full" type="text">
                    <!-- Hidden input to store the Quill editor content -->
                    <input required type="hidden" name="quillContent" id="quillContent">
                    <input required type="hidden" name="category" value="<?php echo($_GET['c']); ?>">
                    <div class="flex justify-between">
                        <h3 class="text-xl crimson-text-regular text-gray-700">
                            मजकूर
                        </h3>
                        <h3 id="wordCountDisplay" class="text-xl crimson-text-regular text-gray-700">
                            Word Count: 00
                        </h3>
                    </div>
                    <div id="editor-container"></div>
                    <div id="progress-bar"></div>
                    <div class="flex justify-end w-full">


                        <button class="border mr-8 bg-red-700 text-white rounded mt-2 py-1 px-4 hammersmith-one-regular" type="button" id="nextButton">Next</button>
                    </div>
                </div>

                <!-- Form 2: Submit Section -->
                <div id="form2" class="px-6 py-6 border relative form2 w-full h-full">

                    <div class="">
                        <button type="button" id="openModalBtn" class="bg-blue-500 text-white px-4 py-2">
                            Create Cover
                        </button>
                    </div>
                    <div class="">
                        <!-- Hidden input to store the image data -->
                        <input type="hidden" id="savedImage" name="savedImage">

                        <!-- Image preview element -->
                        <img id="imagePreview" src="" alt="Image Preview" class="mt-4 w-64 object-cover border-2">
                    </div>
                    <div class="genres_selector">
                        <?php
                        require_once("genreSelector.php"); ?>
                    </div>
                    <div class="tag_selector">
                        <?php
                        require_once("tagSelector/tagSelector.php"); ?>
                    </div>

                    <div class="flex justify-between">
                        <button class="mr-8 bg-red-700 text-white mt-2 py-1 px-4 hammersmith-one-regular" type="button" id="prevButton">Previous</button>
                        <button class="bg-red-700 text-white mt-2 py-1 px-4 hammersmith-one-regular" type="submit">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    <!-- The Modal -->
    <?php
    require_once("FabricEditor/editor_covermodal.php"); ?>

</div>
<!-- Fabric Modal Handler JavaScript -->
<?php require_once("FabricEditor/editor.ModalHandler.js.php"); ?>

<!-- Quill Editor JavaScript -->
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
<?php require_once("QuillEditor/editor.QuillScript.js.php"); ?>

<!-- FabricEditor JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>

<!-- The Modal JavaScript -->
<?php require_once("FabricEditor/editor_covermodal_js.php"); ?>

</body>
</html>