<style>


  .genre-selector {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    max-width: 400px;
  }

  .genre-option {
    position: relative;
    display: flex;
    align-items: center;
    padding: 2px 2px;
    background: #ccc;
    border-radius: 200px;
    background-color: white;
    color: #007BFF;
    cursor: pointer;
    user-select: none;
    transition: background-color 0.3s, color 0.3s, transform 0.3s ease;
    order: 0;
    /* Default order */
  }

  .genre-option input[type="checkbox"] {
    position: absolute;
    opacity: 0;
    cursor: pointer;
  }

  .genre-option input[type="checkbox"]:checked ~ label {
    background-color: #007BFF;
    color: white;
    border-radius: 100px;
    padding: 2px 8px;
    /* Slight zoom on select */
  }

  .genre-option input[type="checkbox"]:checked ~ label .icon-cross {
    display: none;
  }

  .genre-option input[type="checkbox"]:checked ~ label .icon-check {
    display: inline;
  }

  .genre-option label {
    padding: 0 10px;
    background: #eee;
    border-radius: 999px;
    color: black;
    cursor: pointer;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    transition: order 0.3s ease;
  }

  .icon-check {
    display: none;
    margin-left:0 10px;
    width: 18px;
    height: 18px;
    transition: transform 0.3s ease;
  }

  .icon-cross {
    display: inline;
    margin-left:0 10px;
    width: 18px;
    height: 18px;
    transition: transform 0.3s ease;
  }

  .disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }
</style>
<div class="font-bold py-2 mt-4">
  Select One Genre
</div>
<div class="genre-selector">
  <?php
  $PDO = DatabaseConnection::getPdo(); // Assuming this returns a PDO object

  $SQL = "
  SELECT *
    FROM
      genres;
      ";
  $stmt = $PDO->prepare($SQL); // Prepare the SQL statement
  $stmt->execute(); // Execute the prepared statement

  $results = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all results as an associative array
    foreach ($results as $row) {
      $genrename= $row["genrename"];
  ?>
  <div class="genre-option">
    <input name="genre" type="checkbox" id="genre-<?php echo $genrename; ?>">
    <label for="genre-<?php echo $genrename; ?>">
      <?php echo $genrename; ?>
      <!--<span class="icon-cross">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </span>-->
      <span class="icon-check">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
        </svg>
      </span>
    </label>
  </div>

  <?php
    }
  ?>
</div>

<script>
  const MAX_SELECTIONS = 3;

  function updateSelection() {
    const checkboxes = document.querySelectorAll('.genre-option input[type="checkbox"]');
    let selectedCount = 0;

    checkboxes.forEach(checkbox => {
      if (checkbox.checked) {
        selectedCount++;
      }
    });

    checkboxes.forEach(checkbox => {
      if (selectedCount >= MAX_SELECTIONS && !checkbox.checked) {
        checkbox.disabled = true;
        checkbox.parentElement.classList.add('disabled');
      } else {
        checkbox.disabled = false;
        checkbox.parentElement.classList.remove('disabled');
      }
    });
  }

  document.querySelectorAll('.genre-option input[type="checkbox"]').forEach(function(checkbox) {
    checkbox.addEventListener('change', function() {
      const parent = this.closest('.genre-option');
      if (this.checked) {
        parent.style.order = -1; // Move selected genre to the front
      } else {
        parent.style.order = 0; // Reset order to default
      }

      updateSelection(); // Update selection state
    });
  });

  // Initialize the selection state
  updateSelection();
</script>