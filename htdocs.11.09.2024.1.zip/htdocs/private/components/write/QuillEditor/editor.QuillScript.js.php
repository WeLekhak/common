<script>
    function countWords() {
        const text = quill.getText().trim();
        const wordCount = text.split(/\s+/).filter(word => word.length > 0).length;
        return wordCount;
    }
    // JavaScript to toggle between form1 and form2 with width transition
    document.getElementById('nextButton').addEventListener('click', function() {
        document.getElementById('formContainer').classList.remove('show-form1');
        document.getElementById('formContainer').classList.add('show-form2');
    });

    document.getElementById('prevButton').addEventListener('click', function() {
        document.getElementById('formContainer').classList.remove('show-form2');
        document.getElementById('formContainer').classList.add('show-form1');
    });
    var quill = new Quill('#editor-container', {
        theme: 'snow',
        modules: {
            toolbar: {
                container: [
                    ['bold',
                        'italic',
                        'underline'],
                    [{
                        'align': ''
                    },
                        {
                            'align': 'center'
                        },
                        {
                            'align': 'right'
                        },
                        {
                            'align': 'justify'
                        }],
                    ['image']
                ],
                handlers: {
                    'image': imageHandler
                }
            }
        }
    });
    // Update hidden input value when the content changes
    quill.on('text-change', function() {
        const wordCount = countWords();
        document.getElementById('wordCountDisplay').innerText = `Word Count: ${wordCount}`;
        var quillContent = document.querySelector('input[name=quillContent]');
        quillContent.value = quill.root.innerHTML;
    });

    function imageHandler() {
        var input = document.createElement('input');
        input.setAttribute('type',
            'file');
        input.setAttribute('accept',
            'image/*');
        input.click();

        input.onchange = function() {
            var file = input.files[0];
            var formData = new FormData();
            formData.append('image',
                file);

            var xhr = new XMLHttpRequest();
            xhr.open('POST',
                'upload.php',
                true);

            // Show progress bar
            var progressBar = document.getElementById('progress-bar');
            progressBar.style.display = 'block';

            xhr.upload.onprogress = function(event) {
                if (event.lengthComputable) {
                    var percentComplete = Math.round((event.loaded / event.total) * 100);
                    progressBar.style.width = percentComplete + '%';
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    var result = JSON.parse(xhr.responseText);
                    if (result.success) {
                        var range = quill.getSelection();
                        quill.insertEmbed(range.index, 'image', result.imageUrl);
                    } else {
                        console.error('Upload failed:', result.error);
                    }
                } else {
                    console.error('Error:', xhr.statusText);
                }

                // Hide progress bar after upload completes
                progressBar.style.display = 'none';
                progressBar.style.width = '0%';
            };

            xhr.onerror = function() {
                console.error('Upload failed. Please try again.');
                progressBar.style.display = 'none';
                progressBar.style.width = '0%';
            };

            xhr.send(formData);
        };
    }

    // Assuming `savedContent` contains the HTML returned by the server
    const savedContent = "<?php echo isset($_POST['quillContent']) ? $_POST['quillContent'] : ''; ?>";
    quill.root.innerHTML = savedContent;

</script>