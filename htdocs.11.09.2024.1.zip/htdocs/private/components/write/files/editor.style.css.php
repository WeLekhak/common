<style>
    #progress-bar {
        width: 0;
        height: 5px;
        background-color: green;
        display: none;
    }
    /* Make the toolbar sticky */
    .ql-toolbar {
        position: -webkit-sticky;
        position: sticky;
        top: 0;
        z-index: 100;
        background-color: #fff;
        border-bottom: 2px solid #ccc;
    }

    /* Customize indentation for new paragraphs */
    .ql-editor p {
        text-indent: 2em;
        margin: 0;
    }
    .ql-editor {
        min-height: 300px;
    }
    /* Transition effect for width */
    .form-container {
        display: flex;
        width: 200%;
        transition: transform 0.5s ease-in-out;
    }

    .form1, .form2 {
        width: 50%;
        transition: width 0.5s ease-in-out;
    }

    /* Hide and Show with width */
    .show-form1 {
        transform: translateX(0);
    }

    .show-form2 {
        transform: translateX(-50%);
    }

    .hidden {
        display: none;
    }
    /* Custom transition classes for modal visibility */
    .modal-show {
        opacity: 1;
        visibility: visible;
    }

    .modal-hide {
        opacity: 0;
        visibility: hidden;
    }

    /* Transition effect */
    .modal-transition {
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }
</style>