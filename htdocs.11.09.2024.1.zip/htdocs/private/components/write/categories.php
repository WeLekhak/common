<main>
    <div class="crimson-text-regular px-2 border-indigo-700 outer mt-20">
        <div class="px-6 content flex-col flex items-center justify-center">
            <div class="flex mt-4 submain submain-1">
                <a href="/write/?c=story" class="flex mr-3 rounded-md text-white text-4xl items-center justify-center  bg-gradient-to-r from-blue-800 to-indigo-900 w-40 h-36 type1">
                    <span>कथा</span>
                </a>
                <a href="/write/?c=poetry" class="flex ml-3 rounded-md text-white text-4xl items-center justify-center bg-gradient-to-r from-pink-500 to-rose-500 w-40 h-36 type1">
                    <span>कविता</span>
                </a>

            </div>
            <div class="flex mt-4 submain submain-1">
                <a href="/write/?c=article" class="flex mr-3 rounded-md text-white text-4xl items-center justify-center bg-gradient-to-r from-amber-500 to-pink-500 w-40 h-36 type1">
                    <span>लेख</span>
                </a>
                <a href="/write/?c=series" class="flex ml-3 rounded-md text-white text-4xl items-center justify-center bg-gradient-to-r from-emerald-500 to-emerald-900 w-40 h-36 type1">
                    <span class="text-center">
                        कथा <br />
                        मालिका
                    </span>
                </a>

            </div>
            <div class="flex w-full mt-4 submain submain-1">
                <a href="/write/competition/" class="flex  rounded text-white text-2xl items-center justify-center bg-gradient-to-r from-slate-700 to-slate-900 w-full h-16 type1">
                    <span>स्पर्धेसाठी लिखाण करा</span>
                </a>

            </div>

        </div>
    </div>
</main>