<?php
require_once("../../../../config/db_config.php");
try {
    // Get the PDO instance
    $pdo = DatabaseConnection::getPdo();

    // Get the query parameter from the URL
    $query = isset($_GET['q']) ? $_GET['q'] : '';

    // Prepare and execute the query
    $stmt = $pdo->prepare("SELECT tagname FROM tags WHERE tagname LIKE :query LIMIT 10");
    $stmt->execute([':query' => '%' . $query . '%']);
    $tags = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Return the tags as a JSON array
    echo json_encode($tags);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>