<div class="mt-4 pb-24">
  <div class="font-bold py-2 mt-4">
    Select Tags.
  </div>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tagify/4.9.4/tagify.css">
  <input name='tags' placeholder='Type and select tags...' class='tagify-input'>
  <p id="warning" style="color: red; display: none;">
    You can only add up to 10 tags.
  </p>
  <!-- Tagify JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tagify/4.9.4/tagify.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tagify/4.9.4/tagify.polyfills.min.js"></script>

  <script>
    // Initialize Tagify on the input field
    var input = document.querySelector('.tagify-input');
    var tagify = new Tagify(input, {
      whitelist: [],
      dropdown: {
        enabled: 0 // always show suggestions dropdown
      }
    });

    // Maximum number of tags allowed
    var maxTags = 10;

    // Handle the 'add' event
    tagify.on('add', function(e) {
      if (tagify.value.length > maxTags) {
        // Remove the last added tag
        tagify.removeTag(e.detail.tag);

        // Show warning message
        document.getElementById('warning').style.display = 'block';
      } else {
        // Hide warning message if the number of tags is within the limit
        document.getElementById('warning').style.display = 'none';
      }
    });

    // Fetch tags from the server as the user types
    tagify.on('input', function(e) {
      fetchTagsFromServer(e.detail.value);
    });

    function fetchTagsFromServer(query) {
      fetch('fetchTags.php?q=' + query)
      .then(RES => RES.json())
      .then(function(whitelist) {
        // Update Tagify whitelist with the fetched data
        tagify.settings.whitelist.length = 0; // reset the whitelist array
        tagify.settings.whitelist.push(...whitelist); // replace it with the new data
        tagify.dropdown.show.call(tagify, query); // render the suggestions dropdown
      });
    }
  </script>
</div>