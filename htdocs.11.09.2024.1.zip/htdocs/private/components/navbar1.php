<nav class="border-b-2">
  <style type="text/css" media="all">
    #mobile-menu, [role="menu"] {
      transition: opacity 0.15s ease-in-out, transform 0.15s ease-in-out;
    }
    #mobile-menu {
      overflow: hidden;
      height: 0;
      transition: height 0.3s ease;
    }
  </style>
  <div class="mx-auto max-w-7xl px-2 sm:px-8 lg:px-8">
    <!-- Mobile menu, show/hide based on menu state. -->
    <div class="sm:hidden" id="mobile-menu">
      <div class="space-y-1 px-2 pb-3 pt-2">
        <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
        <a href="#" class="block px-3 py-2 text-base font-medium bg-gray-700 text-white" aria-current="page">Homepage</a>
        <a href="#" class="block px-3 py-2 text-base font-medium text-gray-600 hover:bg-gray-300 hover:text-gray-700 hover:border-l-4 hover:border-gray-500">Team</a>
        <a href="#" class="block px-3 py-2 text-base font-medium text-gray-600 hover:bg-gray-300 hover:text-gray-700 hover:border-l-4 hover:border-gray-500">Projects</a>
        <a href="#" class="block px-3 py-2 text-base font-medium text-gray-600 hover:bg-gray-300 hover:text-gray-700 hover:border-l-4 hover:border-gray-500">Calendar</a>
      </div>
    </div>
    <div class="relative flex h-16 items-center justify-between">
      <div class="absolute inset-y-0 left-0 flex items-center sm:hidden">
        <!-- Mobile menu button-->
        <button type="button" class="relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white" aria-controls="mobile-menu" aria-expanded="false">
          <span class="absolute -inset-0.5"></span>
          <span class="sr-only">Open main menu</span>
          <!--
                                                                                                                                                                                                                                                                                                                                                      Icon when menu is closed.

                                                                                                                                                                                                                                                                                                                                                      Menu open: "hidden", Menu closed: "block"
                                                                                                                                                                                                                                                                                                                                                    -->
          <svg class="hidden" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="m16.192 6.344-4.243 4.242-4.242-4.242-1.414 1.414L10.535 12l-4.242 4.242 1.414 1.414 4.242-4.242 4.243 4.242 1.414-1.414L13.364 12l4.242-4.242z"></path></svg>
          <!--
                                                                                                                                                                                                                                                                                                                                                      Icon when menu is open.

                                                                                                                                                                                                                                                                                                                                                      Menu open: "block", Menu closed: "hidden"
                                                                                                                                                                                                                                                                                                                                                    -->
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"></path></svg>
        </button>
      </div>
      <div class="flex flex-1 items-center justify-center sm:items-stretch sm:justify-start">
        <div class="flex flex-shrink-0 items-center">
          <img class="h-8 w-auto" src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=500" alt="Your Company">
        </div>
        <div class="hidden sm:ml-6 sm:block">
          <div class="flex space-x-4">
            <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white" -->
            <a href="#" class=" bg-gray-900 px-3 py-2 text-sm font-medium text-white" aria-current="page">Dashboard</a>
            <a href="#" class=" px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-200 hover:text-gray-700">Team</a>
            <a href="#" class=" px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-200 hover:text-gray-700">Projects</a>
            <a href="#" class=" px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-200 hover:text-gray-700">Calendar</a>
          </div>
        </div>
      </div>
      <div class="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">
        <a href="/write/" type="button" class="relative rounded-full bg-gray-800 p-1 text-gray-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800">
          <span class="absolute -inset-1.5"></span>
          <span class="sr-only">View notifications</span>
          <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
          </svg>
        </a>

        <!-- Profile dropdown -->
        <div class="relative ml-3">
          <div>
            <button type="button" class="relative flex rounded-full bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800" id="user-menu-button" aria-expanded="false" aria-haspopup="true">
              <span class="absolute -inset-1.5"></span>
              <span class="sr-only">Open user menu</span>
              <img class="h-8 w-8 rounded-full" src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="">
            </button>
          </div>

          <!--
                                                                                                                                                                                                                                                                                                                                                      Dropdown menu, show/hide based on menu state.

                                                                                                                                                                                                                                                                                                                                                      Entering: "transition ease-out duration-100"
                                                                                                                                                                                                                                                                                                                                                        From: "transform opacity-0 scale-95"
                                                                                                                                                                                                                                                                                                                                                        To: "transform opacity-100 scale-100"
                                                                                                                                                                                                                                                                                                                                                      Leaving: "transition ease-in duration-75"
                                                                                                                                                                                                                                                                                                                                                        From: "transform opacity-100 scale-100"
                                                                                                                                                                                                                                                                                                                                                        To: "transform opacity-0 scale-95"
                                                                                                                                                                                                                                                                                                                                                    -->
          <div class="absolute hidden right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none" role="menu" aria-orientation="vertical" aria-labelledby="user-menu-button" tabindex="-1">
            <!-- Active: "bg-gray-100", Not Active: "" -->
            <a href="/Profile/" class="block px-4 py-2 text-sm text-gray-700" role="menuitem" tabindex="-1" id="user-menu-item-0">Your Profile</a>
            <a href="/Settings/" class="block px-4 py-2 text-sm text-gray-700" role="menuitem" tabindex="-1" id="user-menu-item-1">Settings</a>
            <a href="<?php echo $_SERVER["HTTP_HOST"] ?>/logout.php" class="block px-4 py-2 text-sm text-gray-700" role="menuitem" tabindex="-1" id="user-menu-item-2">Sign out</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" charset="utf-8">
    // Get elements
    const mobileMenuButton = document.querySelector('button[aria-controls="mobile-menu"]');
    const mobileMenu = document.getElementById('mobile-menu');
    const userMenuButton = document.getElementById('user-menu-button');
    const userMenu = document.querySelector('[role="menu"]');

    // Function to handle mobile menu height transition
    function toggleMobileMenu() {
      const isExpanded = mobileMenuButton.getAttribute('aria-expanded') === 'true';
      mobileMenuButton.setAttribute('aria-expanded', !isExpanded);

      if (!isExpanded) {
        mobileMenu.style.height = '0px';
        mobileMenu.classList.remove('hidden'); // Ensure menu is visible for transition
        setTimeout(() => {
          mobileMenu.style.height = mobileMenu.scrollHeight + 'px';
        }, 10);
      } else {
        mobileMenu.style.height = mobileMenu.scrollHeight + 'px';
        setTimeout(() => {
          mobileMenu.style.height = '0px';
        }, 10);
      }
    }

    // Function to handle user menu visibility
    function toggleUserMenu() {
      const isExpanded = userMenuButton.getAttribute('aria-expanded') === 'true';
      userMenuButton.setAttribute('aria-expanded', !isExpanded);

      userMenu.classList.toggle('hidden'); // Show/hide menu with no height transition
    }

    // Event listeners
    mobileMenuButton.addEventListener('click', toggleMobileMenu);
    userMenuButton.addEventListener('click', toggleUserMenu);

    // Reset height after mobile menu transition
    mobileMenu.addEventListener('transitionend', () => {
      if (mobileMenu.style.height === '0px') {
        mobileMenu.classList.add('hidden'); // Hide the menu after collapse
      } else {
        mobileMenu.style.height = 'auto'; // Set height to auto after expansion
      }
    });

    // Close menus when clicking outside
    document.addEventListener('click', (event) => {
      // Close mobile menu
      if (!mobileMenuButton.contains(event.target) && !mobileMenu.contains(event.target) && !mobileMenu.classList.contains('hidden')) {
        mobileMenu.style.height = '0px';
        mobileMenuButton.setAttribute('aria-expanded', 'false');
      }

      // Close user menu
      if (!userMenuButton.contains(event.target) && !userMenu.contains(event.target) && !userMenu.classList.contains('hidden')) {
        userMenu.classList.add('hidden');
        userMenuButton.setAttribute('aria-expanded', 'false');
      }
    });

  </script>
</nav>