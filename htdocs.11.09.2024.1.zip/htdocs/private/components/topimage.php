  <aside class="relative block h-32 lg:order-last lg:col-span-5 lg:h-full xl:col-span-6">
    <img
    alt=""
    src="../assets/images/cover.jpg"
    class="absolute inset-0 h-full w-full object-cover"
    />
  </aside>