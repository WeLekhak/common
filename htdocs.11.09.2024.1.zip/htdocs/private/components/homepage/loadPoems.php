<div class="">
  <div class="categories_title px-6 text-xl mb-2 mt-2">
    <h3 class="crimson-text-regular">
      प्रसिद्ध कविता
    </h3>
  </div>
  <div class="hide-scrollbar flex px-6 mb-2 overflow-x-auto">

    <?php
    $PDO2 = DatabaseConnection::getPdo(); // Assuming this returns a PDO object

    $SQL2 = "
  SELECT
    p.*,
    u.lekhak_firstname,
    u.lekhak_lastname,
    COALESCE(pr.read_count, 0) AS total_reads,
    COALESCE(pl.like_count, 0) AS total_likes,
    GROUP_CONCAT(DISTINCT t.tagname SEPARATOR ', ') AS tags,
    GROUP_CONCAT(DISTINCT g.genrename SEPARATOR ', ') AS genres
FROM
    posts AS p
LEFT JOIN
    lekhak_users AS u ON p.author = u.lekhak_user_id
LEFT JOIN
    (SELECT postread_postid, COUNT(*) AS read_count
     FROM postreads
     GROUP BY postread_postid) AS pr ON p.id = pr.postread_postid
LEFT JOIN
    (SELECT postid, COUNT(*) AS like_count
     FROM post_likes
     GROUP BY postid) AS pl ON p.id = pl.postid
LEFT JOIN
    posttags AS pt ON p.id = pt.posttags_postid
LEFT JOIN
    tags AS t ON pt.posttags_tagid = t.tagid
LEFT JOIN
    postgenres AS pg ON p.id = pg.postid
LEFT JOIN
    genres AS g ON pg.genreid = g.genreid
WHERE
    p.category = 'poetry'
GROUP BY
    p.id
ORDER BY
    p.id DESC
LIMIT 10;
  ";
    $stmt2 = $PDO2->prepare($SQL2); // Prepare the SQL statement
    $stmt2->execute(); // Execute the prepared statement

    $results2 = $stmt2->fetchAll(PDO::FETCH_ASSOC); // Fetch all results as an associative array
    // Update the allowed HTML tags
    Purifier::setConfig([
      'HTML.Allowed' => [
        'p',
        'a[href|title]',
      ],
    ]);

    // Purify HTML again with updated allowed tags

    foreach ($results2 as $row2) {
      $poem_content = Purifier::purify($row2["content"]);
      $poem_content = removeBrTags($poem_content);
      ?>


      <div class="poembox mr-3 min-w-44 overflow-y-hidden h-64 w-44 border-4 px-1 ">
        <div id="ribbon2" class="ribbon text-black pl-4 ribbonx min-w-0 w-auto">
          <span class="crimson-text-regular font-bold whitespace-nowrap text-ellipsis">
            <?php echo $row2["title"] ?>
          </span>
        </div>
        <div class="poemcontent crimson-text-regular px-1">
          <?php echo $poem_content; ?>
        </div>
      </div>
      <?php
    }
    ?>
  </div>
  <div class="flex justify-end items-right">
    <div class="flex border-b border-blue-700 px-6 mt-1 text-blue-700">
      <a class="crimson-text-regular" href="/poems/">
        सर्व कविता पहा...
      </a>
      <span class="flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-5">
          <path fill-rule="evenodd" d="M2 10a.75.75 0 0 1 .75-.75h12.59l-2.1-1.95a.75.75 0 1 1 1.02-1.1l3.5 3.25a.75.75 0 0 1 0 1.1l-3.5 3.25a.75.75 0 1 1-1.02-1.1l2.1-1.95H2.75A.75.75 0 0 1 2 10Z" clip-rule="evenodd" />
        </svg>
      </span>
    </div>
  </div>
  <div class="h-2 w-full bg-gray-200 mt-1">
  </div>
</div>