<style type="text/css" media="all">
  .category_card {
    background-image: url('assets/images/imageCT.jpeg');
  }
</style>
<div class="categories_title px-6 text-xl mt-4">
  <h3 class="crimson-text-regular">शैली नुसार वाचा.</h3>
</div>
<div class="hide-scrollbar categories overflow-scroll py-2 px-6 flex">
  <?php
  $PDO3 = DatabaseConnection::getPdo(); // Assuming this returns a PDO object

  $SQL3 = "
  SELECT
    g.genreid,
    g.genrename,
    COUNT(p.id) AS post_count
FROM
    genres AS g
INNER JOIN
    postgenres AS pg ON g.genreid = pg.genreid
INNER JOIN
    posts AS p ON pg.postid = p.id
WHERE
      p.timecreated >= (
        SELECT MIN(sub.timecreated)
        FROM (
            SELECT DISTINCT DATE(timecreated) AS timecreated
            FROM posts
            WHERE category = 'poetry'
            ORDER BY timecreated DESC
            LIMIT 7
        ) AS sub
    )
GROUP BY
    g.genreid, g.genrename
ORDER BY
    post_count DESC
LIMIT 10;
  ";


  $stmt3 = $PDO3->prepare($SQL3); // Prepare the SQL statement
  $stmt3->execute(); // Execute the prepared statement

  $results3 = $stmt3->fetchAll(PDO::FETCH_ASSOC); // Fetch all results as an associative array
  foreach ($results3 as $row3) {
    $genrename = $row3["genrename"];
    ?>

    <a href="/genres/index.php?genre=<?php echo $genrename ?>" class="text-white bg-gradient-to-tl from-slate-900 via-transparent via-50% to-transparent category_card overflow-hidden relative min-w-36 h-20 border mr-3 rounded-md">
      <div class="category_title">
        <span class="crimson-text-regular font-bold">
          <?php echo $genrename ?>
        </span>
      </div>
    </a>

    <?php
  }
  ?>
</div>
<div class="flex justify-end items-right">
  <div class="flex border-b border-blue-700 px-6 mt-1 text-blue-700">
    <a class="crimson-text-regular" href="/genres/">
      सर्व शैली पहा...
    </a>
    <span class="flex items-center justify-center">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="size-5">
        <path fill-rule="evenodd" d="M2 10a.75.75 0 0 1 .75-.75h12.59l-2.1-1.95a.75.75 0 1 1 1.02-1.1l3.5 3.25a.75.75 0 0 1 0 1.1l-3.5 3.25a.75.75 0 1 1-1.02-1.1l2.1-1.95H2.75A.75.75 0 0 1 2 10Z" clip-rule="evenodd" />
      </svg>
    </span>
  </div>
</div>
<div class="h-2 w-full bg-gray-200 mt-1">
</div>