<?php

class LanguageHandler {
    // Static array mapping languages to categories and texts
    private static $translations = [
        'mr' => [
            'genres' => [
                'love' => 'प्रेम',
                'horror' => 'भय',
                'drama' => 'नाटक',
                'action' => 'कृती',
            ],
            'labels' => [
                'submit' => 'साबित करा',
                'cancel' => 'रद्द करा',
                'welcome' => 'स्वागत आहे',
            ],
            'categories' => [
                'story' => 'कथा',
                'poetry' => 'काव्य',
                'article' => 'लेख',
                'series' => 'लेखामालिका',
                ],
            // Add more categories and texts as needed
        ],
        'mr-ams-aaditya-calli' => [
            'genres' => [
                'religious' => 'YaamaIQk',
                'love' => 'paXema',
                'realist' => 'vaasta[vaktaa',
                'politics' => 'raja[kya',
                'literary' => 'saa[htya{k!',
                'tragedy' => 'Saaeka/[taka',
                'inspiration' => 'paXaetsaahNapar',
            ],
            'labels' => [
                'submit' => 'साबित करा',
                'cancel' => 'रद्द करा',
                'welcome' => 'स्वागत आहे',
            ],
            'categories' => [
                'story' => 'Kath',
                
                ],
            // Add more categories and texts as needed
        ],
        'es' => [
            'genres' => [
                'love' => 'Amor',
                'horror' => 'Horror',
                'drama' => 'Drama',
                'action' => 'Acción',
            ],
            'labels' => [
                'submit' => 'Enviar',
                'cancel' => 'Cancelar',
                'welcome' => 'Bienvenido',
            ],
            // Add more categories and texts as needed
        ],
        'fr' => [
            'genres' => [
                'love' => 'Amour',
                'horror' => 'Horreur',
                'drama' => 'Drame',
                'action' => 'Action',
            ],
            'labels' => [
                'submit' => 'Soumettre',
                'cancel' => 'Annuler',
                'welcome' => 'Bienvenue',
            ],
            // Add more categories and texts as needed
        ],
        'en' => [
            'genres' => [
                'love' => 'Love',
                'horror' => 'Horror',
                'drama' => 'Drama',
                'action' => 'Action',
            ],
            'labels' => [
                'submit' => 'Submit',
                'cancel' => 'Cancel',
                'welcome' => 'Welcome',
            ],
            // Add more categories and texts as needed
        ],
    ];

    // Static method to get the translation for a specific category and text
    public static function getTranslation($language, $category, $text) {
        // Check if the language and category exist in the translations array
        if (isset(self::$translations[$language]) &&
            isset(self::$translations[$language][$category]) &&
            isset(self::$translations[$language][$category][$text])) {
            return self::$translations[$language][$category][$text];
        }

        // Fallback to English if the translation is not available
        return isset(self::$translations['en'][$category][$text]) ? self::$translations['en'][$category][$text] : ucfirst($text);
    }
}

/**
* Example usage
// Assume $_GET['lang'], $_GET['category'], and $_GET['text'] are set
$selectedText = isset($_GET['text']) ? $_GET['text'] : null;
$category = isset($_GET['category']) ? $_GET['category'] : 'genres';
$language = isset($_GET['lang']) ? $_GET['lang'] : 'en';

// Get the translated text
if ($selectedText !== null) {
$displayText = LanguageHandler::getTranslation($language, $category, $selectedText);
echo $displayText;
} else {
echo "No text selected.";
}
*/
?>